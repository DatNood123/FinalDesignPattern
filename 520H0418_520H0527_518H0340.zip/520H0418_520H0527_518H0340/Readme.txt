Đầu tiên tải code về sau đó vui lòng chạy database với các lệnh đã được mô tả trong thư mục Database(ở đây dùng mysql)
Sau đó vui lòng thay đổi các chuỗi kết nối sao cho phù hợp với tên server,userId,... để tạo ra connectstring phù hợp trong file database.cs, dataPprovider.cs và Code file KetQua.cs
Thực hiện việc insert các button,label,... và thực hiện việc chạy code