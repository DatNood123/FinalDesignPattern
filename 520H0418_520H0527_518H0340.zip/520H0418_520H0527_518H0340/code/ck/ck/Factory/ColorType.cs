﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuoiKy_DP.DataObject.Factory
{
    internal enum ColorType
    {
        White,
        Black,
        Blue,
        Red,
        Green
    }
}