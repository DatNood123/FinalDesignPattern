﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuoiKy_DP.DataObject.Factory
{
    internal enum EngineType
    {
        EEngine01,
        EEngine02,
        DEngine01,
        DEngine02,
        GEngine01,
        GEngine02
    }
}